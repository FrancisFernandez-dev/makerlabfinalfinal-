from django.apps import AppConfig


class BibliotecaConfig(AppConfig):
    name = 'biblioteca'
